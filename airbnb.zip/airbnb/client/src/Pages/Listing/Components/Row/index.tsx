import styled from 'styled-components'

export const Row = styled.div`
    width: 1080px;
    margin: auto;
    display: flex;
`
