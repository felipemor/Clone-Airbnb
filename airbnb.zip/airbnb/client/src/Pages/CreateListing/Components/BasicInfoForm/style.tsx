import styled from 'styled-components'

export const Title = styled.h1`
    margin-bottom: 30px;
    font-size: 28px;
    font-weight: 600;
`
