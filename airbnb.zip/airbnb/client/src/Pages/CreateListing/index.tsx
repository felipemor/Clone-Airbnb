import * as React from 'react'

import { CreateListingForm } from './Components/CreateListingForm'

export const CreateListing: React.SFC<{}> = () => <CreateListingForm />
