import styled from 'styled-components'

export const Br = styled.div`
    width: 100%;
    height: 1px;
    margin: 20px 0 20px 0;
    background-color: #e3e3e3;
`
