export interface JwtPayload {
    id: number
}
