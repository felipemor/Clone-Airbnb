# Airbnb-clone

Link to the frontend: [https://airbnb-clone.netlify.com/](https://airbnb-clone.netlify.com/)

Link to API: [https://airbnb-clone-mm.herokuapp.com/](https://airbnb-clone-mm.herokuapp.com/)

## Screens

![landing](./client/src/Images/Landing.png)
![login](./client/src/Images/Login.png)
![listings](./client/src/Images/Listings.png)
![listing](./client/src/Images/Listing.png)
![create](./client/src/Images/Create.png)
